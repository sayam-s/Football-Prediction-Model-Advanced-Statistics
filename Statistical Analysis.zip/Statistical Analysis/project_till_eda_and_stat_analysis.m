data = readtable('teams_match_features.csv');
head(data);
size(data);
data.Properties.VariableNames
summary(data);
disp(sum(ismissing(data)));
numDuplicates = height(data) - height(unique(data,'rows'));

fprintf('Number of duplicate rows: %d\n', numDuplicates);

%Remove Outliers
data.home_avg_pace = fillmissing(data.home_avg_pace,'median');
data.home_avg_shooting = fillmissing(data.home_avg_shooting,'median');
data.home_avg_passing = fillmissing(data.home_avg_passing,'median');

data.away_avg_pace = fillmissing(data.away_avg_pace,'median');
data.away_avg_shooting = fillmissing(data.away_avg_shooting,'median');
data.away_avg_passing = fillmissing(data.away_avg_passing,'median');

% Inspect the data

size(data)
data.Properties.VariableNames
summary(data);
disp(sum(ismissing(data)));
numDuplicates = height(data) - height(unique(data,'rows'));
numDuplicates;
display(unique(data.x_tournament));

% Remove leading/trailing spaces
data.x_tournament = strtrim(data.x_tournament);

% Merge names that differ only by accents or spelling
data.x_tournament = strrep(data.x_tournament,'Copa América','Copa America');
data.x_tournament = strrep(data.x_tournament,'Copa América qualifier','Copa America qualifier');

display(unique(data.x_tournament));

data.tournament_group = strings(height(data),1);
data.Properties.VariableNames = ...
    strrep(data.Properties.VariableNames, 'x_', '');
disp(data.Properties.VariableNames');

for i = 1:height(data)

    t = data.tournament{i};

    if contains(t,'World Cup')
        data.tournament_group(i) = "World Cup";

    elseif contains(t,'European')
        data.tournament_group(i) = "European Championship";

    elseif contains(t,'Copa America')
        data.tournament_group(i) = "Copa America";

    elseif contains(t,'African')
        data.tournament_group(i) = "Africa Championship";

    elseif contains(t,'Asian')
        data.tournament_group(i) = "Asia Championship";

    elseif contains(t,'CONCACAF')
        data.tournament_group(i) = "CONCACAF";

    elseif contains(t,'Oceania')
        data.tournament_group(i) = "Oceania";

    elseif contains(t,'Nations League')
        data.tournament_group(i) = "Nations League";

    elseif contains(t,'Olympic')
        data.tournament_group(i) = "Olympics";

    elseif contains(lower(t),'friendly')
        data.tournament_group(i) = "Friendly";

    elseif contains(lower(t),'qualifier') || contains(lower(t),'qual')
        data.tournament_group(i) = "Qualifier";

    else
        data.tournament_group(i) = "Other";
    end

end

data.match_outcome = strings(height(data),1);

data.match_outcome(data.home_goals > data.away_goals) = "Home Win";
data.match_outcome(data.home_goals < data.away_goals) = "Away Win";
data.match_outcome(data.home_goals == data.away_goals) = "Draw";
display(head(data, 10));

openvar('data');

outcomeCount = groupsummary(data,"match_outcome");
disp(outcomeCount);





figure;

subplot(1,3,1)
histogram(data.home_elo);
title('Home ELO');

subplot(1,3,2)
histogram(data.away_elo);
title('Away ELO');

subplot(1,3,3)
histogram(data.elo_diff);
title('ELO Difference');

sgtitle('Team Strength Distribution');
%% Group 1: Team Strength - Boxplot

figure;

subplot(1,3,1)
boxplot(data.home_elo);
title('Home ELO');

subplot(1,3,2)
boxplot(data.away_elo);
title('Away ELO');

subplot(1,3,3)
boxplot(data.elo_diff);
title('ELO Difference');

sgtitle('Team Strength Boxplots');

%% Group 2: Player Ratings - Histogram

figure;

subplot(2,2,1)
histogram(data.home_avg_overall);
title('Home Avg Overall');

subplot(2,2,2)
histogram(data.home_max_overall);
title('Home Max Overall');

subplot(2,2,3)
histogram(data.away_avg_overall);
title('Away Avg Overall');

subplot(2,2,4)
histogram(data.away_max_overall);
title('Away Max Overall');

sgtitle('Player Ratings Distribution');
%% Group 2: Player Ratings - Boxplot

figure;

subplot(2,2,1)
boxplot(data.home_avg_overall);
title('Home Avg Overall');

subplot(2,2,2)
boxplot(data.home_max_overall);
title('Home Max Overall');

subplot(2,2,3)
boxplot(data.away_avg_overall);
title('Away Avg Overall');

subplot(2,2,4)
boxplot(data.away_max_overall);
title('Away Max Overall');

sgtitle('Player Ratings Boxplots');
%% Group 3: Attack & Defense - Histogram

figure;

subplot(2,3,1)
histogram(data.home_avg_attack);
title('Home Attack');

subplot(2,3,2)
histogram(data.away_avg_attack);
title('Away Attack');

subplot(2,3,3)
histogram(data.attack_diff);
title('Attack Difference');

subplot(2,3,4)
histogram(data.home_avg_defense);
title('Home Defense');

subplot(2,3,5)
histogram(data.away_avg_defense);
title('Away Defense');

subplot(2,3,6)
histogram(data.defense_diff);
title('Defense Difference');

sgtitle('Attack & Defense Distribution');
%% Group 3: Attack & Defense - Boxplot

figure;

subplot(2,3,1)
boxplot(data.home_avg_attack);
title('Home Attack');

subplot(2,3,2)
boxplot(data.away_avg_attack);
title('Away Attack');

subplot(2,3,3)
boxplot(data.attack_diff);
title('Attack Difference');

subplot(2,3,4)
boxplot(data.home_avg_defense);
title('Home Defense');

subplot(2,3,5)
boxplot(data.away_avg_defense);
title('Away Defense');

subplot(2,3,6)
boxplot(data.defense_diff);
title('Defense Difference');

sgtitle('Attack & Defense Boxplots');
%% Group 4: Recent Form - Histogram

figure;

subplot(2,3,1)
histogram(data.home_form_scored);
title('Home Goals Scored');

subplot(2,3,2)
histogram(data.home_form_conceded);
title('Home Goals Conceded');

subplot(2,3,3)
histogram(data.home_form_win_rate);
title('Home Win Rate');

subplot(2,3,4)
histogram(data.away_form_scored);
title('Away Goals Scored');

subplot(2,3,5)
histogram(data.away_form_conceded);
title('Away Goals Conceded');

subplot(2,3,6)
histogram(data.away_form_win_rate);
title('Away Win Rate');

sgtitle('Recent Form Distribution');
%% Group 4: Recent Form - Boxplot

figure;

subplot(2,3,1)
boxplot(data.home_form_scored);
title('Home Goals Scored');

subplot(2,3,2)
boxplot(data.home_form_conceded);
title('Home Goals Conceded');

subplot(2,3,3)
boxplot(data.home_form_win_rate);
title('Home Win Rate');

subplot(2,3,4)
boxplot(data.away_form_scored);
title('Away Goals Scored');

subplot(2,3,5)
boxplot(data.away_form_conceded);
title('Away Goals Conceded');

subplot(2,3,6)
boxplot(data.away_form_win_rate);
title('Away Win Rate');

sgtitle('Recent Form Boxplots');
%% Group 5: Goals - Histogram

figure;

subplot(1,2,1)
histogram(data.home_goals);
title('Home Goals');

subplot(1,2,2)
histogram(data.away_goals);
title('Away Goals');

sgtitle('Goals Distribution');
%% Group 5: Goals - Boxplot

figure;

subplot(1,2,1)
boxplot(data.home_goals);
title('Home Goals');

subplot(1,2,2)
boxplot(data.away_goals);
title('Away Goals');

sgtitle('Goals Boxplots');
%% Group 6: Binary Features

figure;

subplot(1,3,1)
bar(countcats(categorical(data.is_neutral)));
title('Neutral Venue');
xlabel('0 = No, 1 = Yes');

% This column has been removed
% subplot(1,3,2)
% bar(countcats(categorical(data.is_world_cup)));
% title('World Cup');
% xlabel('0 = No, 1 = Yes');

subplot(1,3,3)
bar(countcats(categorical(data.is_continental)));
title('Continental');
xlabel('0 = No, 1 = Yes');

sgtitle('Binary Feature Distribution');

% Detect outliers
homeOutliers = isoutlier(data.home_elo);
awayOutliers = isoutlier(data.away_elo);

% Count outliers
numHomeOutliers = sum(homeOutliers);
numAwayOutliers = sum(awayOutliers);

% Calculate percentages
homePercent = (numHomeOutliers / height(data)) * 100;
awayPercent = (numAwayOutliers / height(data)) * 100;

% Display results
fprintf('Home Elo Outliers: %d (%.2f%% of the dataset)\n', numHomeOutliers, homePercent);
fprintf('Away Elo Outliers: %d (%.2f%% of the dataset)\n', numAwayOutliers, awayPercent);

eloDiffOutliers = isoutlier(data.elo_diff);
sum(eloDiffOutliers);

eloDiffOutliers = isoutlier(data.elo_diff);

numOutliers = sum(eloDiffOutliers);
percentage = (numOutliers / height(data)) * 100;

fprintf('Number of outliers in elo_diff: %d\n', numOutliers);
fprintf('Percentage of outliers: %.2f%%\n', percentage);

homeScoreOutliers = isoutlier(data.home_form_scored);
fprintf('Home Score Scored Outliers: %d (%.2f%%)\n', ...
    sum(homeScoreOutliers), (sum(homeScoreOutliers)/height(data))*100);

homeConcededOutliers = isoutlier(data.home_form_conceded);
fprintf('Home Score Conceded Outliers: %d (%.2f%%)\n', ...
    sum(homeConcededOutliers), (sum(homeConcededOutliers)/height(data))*100);

awayScoreOutliers = isoutlier(data.away_form_scored);
fprintf('Away Score Scored Outliers: %d (%.2f%%)\n', ...
    sum(awayScoreOutliers), (sum(awayScoreOutliers)/height(data))*100);

awayConcededOutliers = isoutlier(data.away_form_conceded);
fprintf('Away Score Conceded Outliers: %d (%.2f%%)\n', ...
    sum(awayConcededOutliers), (sum(awayConcededOutliers)/height(data))*100);

homeWinRateOutliers = isoutlier(data.home_form_win_rate);
fprintf('Home Win Rate Outliers: %d (%.2f%%)\n', ...
    sum(homeWinRateOutliers), (sum(homeWinRateOutliers)/height(data))*100);

awayWinRateOutliers = isoutlier(data.away_form_win_rate);
fprintf('Away Win Rate Outliers: %d (%.2f%%)\n', ...
    sum(awayWinRateOutliers), (sum(awayWinRateOutliers)/height(data))*100);
% Attack Difference
attackOutliers = isoutlier(data.attack_diff);

fprintf('Attack Difference Outliers: %d\n', sum(attackOutliers));
fprintf('Percentage: %.2f%%\n', (sum(attackOutliers)/height(data))*100);
% Defense Difference
defenseOutliers = isoutlier(data.defense_diff);

fprintf('Defense Difference Outliers: %d\n', sum(defenseOutliers));
fprintf('Percentage: %.2f%%\n', (sum(defenseOutliers)/height(data))*100);

data.is_world_cup = [];

% fprintf('The is_world_cup column has been removed successfully.\n');
fprintf('Total remaining columns: %d\n', width(data));



neutralCounts = groupcounts(data.is_neutral);

fprintf('Neutral Venue = No (0): %d\n', neutralCounts(1));
fprintf('Neutral Venue = Yes (1): %d\n', neutralCounts(2));


% Bivariate Analysis


% Group 1: Team Strength vs Goals

figure;

subplot(1,2,1)
scatter(data.home_elo,data.home_goals,'filled')
xlabel('Home ELO')
ylabel('Home Goals')
title('Home ELO vs Home Goals')
grid on

subplot(1,2,2)
scatter(data.away_elo,data.away_goals,'filled')
xlabel('Away ELO')
ylabel('Away Goals')
title('Away ELO vs Away Goals')
grid on

sgtitle('Team Strength vs Goals')
%% Group 2: Player Ratings vs Goals

figure;

subplot(1,2,1)
scatter(data.home_avg_overall,data.home_goals,'filled')
xlabel('Home Average Overall')
ylabel('Home Goals')
title('Home Rating vs Home Goals')
grid on

subplot(1,2,2)
scatter(data.away_avg_overall,data.away_goals,'filled')
xlabel('Away Average Overall')
ylabel('Away Goals')
title('Away Rating vs Away Goals')
grid on

sgtitle('Player Ratings vs Goals')
%% Group 3: Attack vs Goals

figure;

subplot(1,2,1)
scatter(data.home_avg_attack,data.home_goals,'filled')
xlabel('Home Attack')
ylabel('Home Goals')
title('Home Attack vs Home Goals')
grid on

subplot(1,2,2)
scatter(data.away_avg_attack,data.away_goals,'filled')
xlabel('Away Attack')
ylabel('Away Goals')
title('Away Attack vs Away Goals')
grid on

sgtitle('Attack Rating vs Goals')
%% Group 4: Defense vs Opponent Goals

figure;

subplot(1,2,1)
scatter(data.home_avg_defense,data.away_goals,'filled')
xlabel('Home Defense')
ylabel('Away Goals')
title('Home Defense vs Away Goals')
grid on

subplot(1,2,2)
scatter(data.away_avg_defense,data.home_goals,'filled')
xlabel('Away Defense')
ylabel('Home Goals')
title('Away Defense vs Home Goals')
grid on

sgtitle('Defense vs Opponent Goals')
%% Group 5: Recent Form vs Goals

figure;

subplot(2,2,1)
scatter(data.home_form_win_rate,data.home_goals,'filled')
xlabel('Home Win Rate')
ylabel('Home Goals')
title('Home Win Rate vs Goals')
grid on

subplot(2,2,2)
scatter(data.away_form_win_rate,data.away_goals,'filled')
xlabel('Away Win Rate')
ylabel('Away Goals')
title('Away Win Rate vs Goals')
grid on

subplot(2,2,3)
scatter(data.home_form_scored,data.home_goals,'filled')
xlabel('Recent Goals Scored')
ylabel('Home Goals')
title('Home Recent Form vs Goals')
grid on

subplot(2,2,4)
scatter(data.away_form_scored,data.away_goals,'filled')
xlabel('Recent Goals Scored')
ylabel('Away Goals')
title('Away Recent Form vs Goals')
grid on

sgtitle('Recent Form vs Goals')
%% Pearson Correlation - Team Strength

r1 = corr(data.home_elo, data.home_goals, 'Rows','complete');
r2 = corr(data.away_elo, data.away_goals, 'Rows','complete');

fprintf('Home ELO vs Home Goals = %.3f\n', r1);
fprintf('Away ELO vs Away Goals = %.3f\n', r2);
%% Pearson Correlation - Player Ratings

r3 = corr(data.home_avg_overall, data.home_goals, 'Rows','complete');
r4 = corr(data.away_avg_overall, data.away_goals, 'Rows','complete');

fprintf('Home Overall vs Home Goals = %.3f\n', r3);
fprintf('Away Overall vs Away Goals = %.3f\n', r4);
%% Pearson Correlation - Attack

r5 = corr(data.home_avg_attack, data.home_goals, 'Rows','complete');
r6 = corr(data.away_avg_attack, data.away_goals, 'Rows','complete');

fprintf('Home Attack vs Home Goals = %.3f\n', r5);
fprintf('Away Attack vs Away Goals = %.3f\n', r6);
%% Pearson Correlation - Defense

r7 = corr(data.home_avg_defense, data.away_goals, 'Rows','complete');
r8 = corr(data.away_avg_defense, data.home_goals, 'Rows','complete');

fprintf('Home Defense vs Away Goals = %.3f\n', r7);
fprintf('Away Defense vs Home Goals = %.3f\n', r8);
%% Pearson Correlation - Recent Form
% 
% r9  = corr(data.home_form_win_rate, data.home_goals, 'Rows','complete');
% r10 = corr(data.away_form_win_rate, data.away_goals, 'Rows','complete');
% 
% r11 = corr(data.home_form_scored, data.home_goals, 'Rows','complete');
% r12 = corr(data.away_form_scored, data.away_goals, 'Rows','complete');
% 
% fprintf('Home Win Rate vs Home Goals = %.3f\n', r9);
% fprintf('Away Win Rate vs Away Goals = %.3f\n', r10);
% 
% fprintf('Home Form Scored vs Home Goals = %.3f\n', r11);
% fprintf('Away Form Scored vs Away Goals = %.3f\n', r12);

data = removevars(data, 'date');

% writetable(data, 'Football_Cleaned_Data.xlsx');

data.Properties.VariableNames

data = removevars(data,'tournament');

% class(data);


% Significance level
alpha = 0.05;

% Numerical variables
numericVars = {'home_elo','away_elo','elo_diff',...
    'home_avg_overall','home_maoverall','home_avg_attack',...
    'home_avg_defense','home_avg_pace','home_avg_shooting',...
    'home_avg_passing','away_avg_overall','away_maoverall',...
    'away_avg_attack','away_avg_defense','away_avg_pace',...
    'away_avg_shooting','away_avg_passing','overall_diff',...
    'attack_diff','defense_diff','home_form_scored',...
    'home_form_conceded','home_form_win_rate',...
    'away_form_scored','away_form_conceded',...
    'away_form_win_rate','home_goals','away_goals'};

fprintf('\n==============================================\n');
fprintf('      HYPOTHESIS TESTING (ONE-WAY ANOVA)\n');
fprintf('Target Variable : match_outcome\n');
fprintf('Significance Level (alpha) = %.2f\n',alpha);
fprintf('==============================================\n\n');

for i = 1:length(numericVars)

    variable = numericVars{i};

    % Perform ANOVA
    p = anova1(data.(variable), data.match_outcome,'off');

    fprintf('Variable : %-25s',variable);

    if p < alpha
        fprintf(' p = %.5f  --> Significant\n',p);
    else
        fprintf(' p = %.5f  --> Not Significant\n',p);
    end

end



%% One-Way ANOVA + Effect Size (Eta Squared)

clc;

alpha = 0.05;

numericVars = {
    'home_elo','away_elo','elo_diff',...
    'home_avg_overall','home_maoverall',...
    'home_avg_attack','home_avg_defense',...
    'home_avg_pace','home_avg_shooting','home_avg_passing',...
    'away_avg_overall','away_maoverall',...
    'away_avg_attack','away_avg_defense',...
    'away_avg_pace','away_avg_shooting','away_avg_passing',...
    'overall_diff','attack_diff','defense_diff',...
    'home_form_scored','home_form_conceded','home_form_win_rate',...
    'away_form_scored','away_form_conceded','away_form_win_rate',...
    'home_goals','away_goals'
    };

fprintf('\n===============================================================\n');
fprintf('        ONE-WAY ANOVA & EFFECT SIZE (ETA SQUARED)\n');
fprintf('===============================================================\n');
fprintf('Target Variable : match_outcome\n');
fprintf('Significance Level (alpha) : %.2f\n',alpha);
fprintf('===============================================================\n');

for i = 1:length(numericVars)

    variable = numericVars{i};

    % Perform One-Way ANOVA
    [p,tbl] = anova1(data.(variable),data.match_outcome,'off');

    % Sum of Squares
    SS_between = cell2mat(tbl(2,2));
    SS_total   = cell2mat(tbl(4,2));

    % Eta Squared
    eta2 = SS_between / SS_total;

    % Print Results
    fprintf('\nVariable      : %s\n',variable);
    fprintf('---------------------------------------------------------------\n');
    fprintf('P-value       : %.6f\n',p);

    if p < alpha
        fprintf('Hypothesis    : Reject H0\n');
        fprintf('Conclusion    : Significant relationship with match_outcome\n');
    else
        fprintf('Hypothesis    : Fail to Reject H0\n');
        fprintf('Conclusion    : No significant relationship\n');
    end

    fprintf('Eta Squared   : %.3f\n',eta2);

    if eta2 < 0.01
        fprintf('Effect Size   : Negligible\n');

    elseif eta2 < 0.06
        fprintf('Effect Size   : Small\n');

    elseif eta2 < 0.14
        fprintf('Effect Size   : Medium\n');

    else
        fprintf('Effect Size   : Large\n');
    end

    fprintf('===============================================================\n');

end

%% Chi-Square Test of Independence

clc;

alpha = 0.05;

categoricalVars = {'is_neutral','is_continental','tournament_group'};

fprintf('\n=============================================================\n');
fprintf('        CHI-SQUARE TEST OF INDEPENDENCE\n');
fprintf('=============================================================\n');
fprintf('Target Variable : match_outcome\n');
fprintf('Significance Level (alpha) : %.2f\n', alpha);
fprintf('=============================================================\n');

for i = 1:length(categoricalVars)

    variable = categoricalVars{i};

    % Chi-Square Test
    [tbl,chi2,p,labels] = crosstab(data.(variable), data.match_outcome);

    fprintf('\nVariable      : %s\n', variable);
    fprintf('-------------------------------------------------------------\n');
    fprintf('Chi-Square    : %.3f\n', chi2);
    fprintf('P-value       : %.6f\n', p);

    if p < alpha
        fprintf('Hypothesis    : Reject H0\n');
        fprintf('Conclusion    : Significant relationship with match_outcome\n');
    else
        fprintf('Hypothesis    : Fail to Reject H0\n');
        fprintf('Conclusion    : No significant relationship\n');
    end

    fprintf('=============================================================\n');

end



%% Chi-Square Test + Cramer's V

clc;

alpha = 0.05;

categoricalVars = {'is_neutral','is_continental','tournament_group'};

fprintf('\n=====================================================================\n');
fprintf('          CHI-SQUARE TEST & CRAMER''S V\n');
fprintf('=====================================================================\n');
fprintf('Target Variable : match_outcome\n');
fprintf('Significance Level (alpha) : %.2f\n', alpha);
fprintf('=====================================================================\n');

for i = 1:length(categoricalVars)

    variable = categoricalVars{i};

    % Contingency Table
    [tbl, chi2, p] = crosstab(data.(variable), data.match_outcome);

    % Sample size
    n = sum(tbl(:));

    % Number of rows and columns
    [r,c] = size(tbl);

    % Cramer's V
    cramerV = sqrt(chi2 / (n * (min(r-1,c-1))));

    fprintf('\nVariable      : %s\n', variable);
    fprintf('---------------------------------------------------------------------\n');
    fprintf('Chi-Square    : %.3f\n', chi2);
    fprintf('P-value       : %.6f\n', p);

    if p < alpha
        fprintf('Hypothesis    : Reject H0\n');
        fprintf('Conclusion    : Significant relationship with match_outcome\n');
    else
        fprintf('Hypothesis    : Fail to Reject H0\n');
        fprintf('Conclusion    : No significant relationship\n');
    end

    fprintf('Cramer''s V    : %.3f\n', cramerV);

    % Interpretation of Cramer's V
    if cramerV < 0.10
        fprintf('Association   : Negligible\n');

    elseif cramerV < 0.30
        fprintf('Association   : Weak\n');

    elseif cramerV < 0.50
        fprintf('Association   : Moderate\n');

    else
        fprintf('Association   : Strong\n');
    end

    fprintf('=====================================================================\n');

end

class(data);

%% Variance Inflation Factor (VIF)

clc;

numericVars = {
    'home_elo','away_elo','elo_diff',...
    'home_avg_overall','home_maoverall',...
    'home_avg_attack','home_avg_defense',...
    'home_avg_pace','home_avg_shooting','home_avg_passing',...
    'away_avg_overall','away_maoverall',...
    'away_avg_attack','away_avg_defense',...
    'away_avg_pace','away_avg_shooting','away_avg_passing',...
    'overall_diff','attack_diff','defense_diff',...
    'home_form_scored','home_form_conceded','home_form_win_rate',...
    'away_form_scored','away_form_conceded','away_form_win_rate'
    };

% Extract numerical data
X = data{:, numericVars};

fprintf('\n=========================================================\n');
fprintf('      VARIANCE INFLATION FACTOR (VIF)\n');
fprintf('=========================================================\n');

for i = 1:size(X,2)

    y = X(:,i);
    X_other = X;
    X_other(:,i) = [];

    % Linear regression
    mdl = fitlm(X_other, y);

    % R-squared
    R2 = mdl.Rsquared.Ordinary;

    % VIF
    vif = 1/(1-R2);

    fprintf('\nVariable : %-25s\n', numericVars{i});
    fprintf('VIF      : %.2f\n', vif);

    if vif < 5
        fprintf('Interpretation : No Multicollinearity\n');
    elseif vif < 10
        fprintf('Interpretation : Moderate Multicollinearity\n');
    else
        fprintf('Interpretation : Severe Multicollinearity\n');
    end

    fprintf('---------------------------------------------------------\n');

end

%% Remove Target Leakage Variables

data = removevars(data, {'home_goals', 'away_goals'});


%% Export Data to Excel

writetable(data, 'football_till_eda.xlsx');

fprintf('Data successfully exported to football_match_prediction_data.xlsx\n');