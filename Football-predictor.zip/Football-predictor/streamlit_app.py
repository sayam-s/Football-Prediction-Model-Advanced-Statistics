"""
Football Match Outcome Predictor — Streamlit App
--------------------------------------------------
Loads the artifacts produced by logistic_regression.py:
  - logisticModel.pkl
  - scaler.pkl        (mu, sigma, numericVars, predictorNames, templateRow)
  - teamStats.pkl

Run with:  streamlit run streamlit_app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
from itertools import combinations

st.set_page_config(page_title="Match Outcome Predictor", layout="wide")

MODEL_PATH = "logisticModel.pkl"
SCALER_PATH = "scaler.pkl"
TEAMSTATS_PATH = "teamStats.pkl"


# ------------------------------------------------------------------
# CACHED LOADERS
# ------------------------------------------------------------------
@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)


@st.cache_resource
def load_scaler():
    return joblib.load(SCALER_PATH)


@st.cache_data
def load_team_stats():
    return joblib.load(TEAMSTATS_PATH)


model = load_model()
scaler = load_scaler()
teamStats = load_team_stats()

mu = scaler["mu"]
sigma = scaler["sigma"]
numericVars = scaler["numericVars"]
predictorNames = scaler["predictorNames"]
templateRow = scaler["templateRow"]

# class order assumed 0=Away, 1=Draw, 2=Home (same convention as training script)
model_classes = list(model.classes_)
homeClassIdx = model_classes.index(2)
drawClassIdx = model_classes.index(1)
awayClassIdx = model_classes.index(0)


# ------------------------------------------------------------------
# Build a predictor row for homeTeam vs awayTeam, same logic as
# STEP 15 / STEP 17 in logistic_regression.py
# ------------------------------------------------------------------
def build_matchup_row(home: pd.Series, away: pd.Series) -> pd.DataFrame:
    row_dict = {
        "home_elo": home["elo"], "away_elo": away["elo"],
        "elo_diff": home["elo"] - away["elo"],

        "home_avg_overall": home["avg_overall"], "home_maoverall": home["maoverall"],
        "home_avg_attack": home["avg_attack"], "home_avg_defense": home["avg_defense"],
        "home_avg_pace": home["avg_pace"], "home_avg_shooting": home["avg_shooting"],
        "home_avg_passing": home["avg_passing"],

        "away_avg_overall": away["avg_overall"], "away_maoverall": away["maoverall"],
        "away_avg_attack": away["avg_attack"], "away_avg_defense": away["avg_defense"],
        "away_avg_pace": away["avg_pace"], "away_avg_shooting": away["avg_shooting"],
        "away_avg_passing": away["avg_passing"],

        "home_form_scored": home["form_scored"], "home_form_conceded": home["form_conceded"],
        "home_form_win_rate": home["form_win_rate"],

        "away_form_scored": away["form_scored"], "away_form_conceded": away["form_conceded"],
        "away_form_win_rate": away["form_win_rate"],
    }
    row_dict["overall_diff"] = row_dict["home_avg_overall"] - row_dict["away_avg_overall"]
    row_dict["attack_diff"] = row_dict["home_avg_attack"] - row_dict["away_avg_attack"]
    row_dict["defense_diff"] = row_dict["home_avg_defense"] - row_dict["away_avg_defense"]

    row = pd.DataFrame([row_dict])
    for col in predictorNames:
        if col not in row.columns:
            row[col] = templateRow[col].values[0]
    row = row[predictorNames]
    row[numericVars] = (row[numericVars] - mu) / sigma
    return row


def predict_matchup(home_team: str, away_team: str):
    home = teamStats[teamStats["team"] == home_team].iloc[0]
    away = teamStats[teamStats["team"] == away_team].iloc[0]
    row = build_matchup_row(home, away)
    probs = model.predict_proba(row)[0]
    return {
        "home_win_pct": probs[homeClassIdx] * 100,
        "draw_pct": probs[drawClassIdx] * 100,
        "away_win_pct": probs[awayClassIdx] * 100,
    }


# ------------------------------------------------------------------
# Top 10 leaderboard: each team as Home vs a league-average Away
# opponent -- same logic as STEP 15
# ------------------------------------------------------------------
@st.cache_data
def compute_top10():
    avgAway = {
        "elo": teamStats["elo"].mean(),
        "avg_overall": teamStats["avg_overall"].mean(),
        "maoverall": teamStats["maoverall"].mean(),
        "avg_attack": teamStats["avg_attack"].mean(),
        "avg_defense": teamStats["avg_defense"].mean(),
        "avg_pace": teamStats["avg_pace"].mean(),
        "avg_shooting": teamStats["avg_shooting"].mean(),
        "avg_passing": teamStats["avg_passing"].mean(),
        "form_scored": teamStats["form_scored"].mean(),
        "form_conceded": teamStats["form_conceded"].mean(),
        "form_win_rate": teamStats["form_win_rate"].mean(),
    }
    avgAway = pd.Series(avgAway)

    rows = []
    for _, t in teamStats.iterrows():
        row = build_matchup_row(t, avgAway)
        probs = model.predict_proba(row)[0]
        rows.append({"team": t["team"], "homeWinPct": probs[homeClassIdx] * 100})

    ranked = pd.DataFrame(rows).sort_values("homeWinPct", ascending=False)
    top10 = ranked.head(10).copy()
    top10["winningPct"] = top10["homeWinPct"] / top10["homeWinPct"].sum() * 100
    return top10[["team", "winningPct"]].reset_index(drop=True)


# ------------------------------------------------------------------
# UI
# ------------------------------------------------------------------
st.title("🏆 Football Match Outcome Predictor")

tab1, tab2 = st.tabs(["Top 10 Winning Teams", "Match Prediction"])

with tab1:
    st.subheader("Top 10 Winning Teams")
    st.caption("Each team as Home vs a league-average Away opponent")
    top10 = compute_top10()
    st.bar_chart(top10.set_index("team")["winningPct"])
    st.dataframe(top10, use_container_width=True, hide_index=True)

with tab2:
    st.subheader("Match Prediction")

    all_teams = sorted(teamStats["team"].unique().tolist())
    default_home = "Argentina" if "Argentina" in all_teams else all_teams[0]
    default_away = "Spain" if "Spain" in all_teams else all_teams[1]

    col1, col2 = st.columns(2)
    with col1:
        home_team = st.selectbox("Team", all_teams, index=all_teams.index(default_home))
    with col2:
        away_team = st.selectbox("Opponent", all_teams, index=all_teams.index(default_away))

    is_final = st.checkbox("Final / knockout match (no draw allowed)", value=True)

    if st.button("Predict Winner", type="primary"):
        if home_team == away_team:
            st.warning("Pick two different teams.")
        else:
            result = predict_matchup(home_team, away_team)
            home_pct, draw_pct, away_pct = (
                result["home_win_pct"], result["draw_pct"], result["away_win_pct"]
            )

            st.write(
                f"Raw model output — {home_team}: {home_pct:.2f}%, "
                f"Draw: {draw_pct:.2f}%, {away_team}: {away_pct:.2f}%"
            )

            if is_final:
                final_home = home_pct / (home_pct + away_pct) * 100
                final_away = away_pct / (home_pct + away_pct) * 100
                winner = home_team if final_home > final_away else away_team

                st.success(f"🏆 Predicted Winner: **{winner}**")
                c1, c2 = st.columns(2)
                c1.metric(f"{home_team} Win", f"{final_home:.1f}%")
                c2.metric(f"{away_team} Win", f"{final_away:.1f}%")
            else:
                outcome_idx = np.argmax([home_pct, draw_pct, away_pct])
                outcome_label = [f"{home_team} Win", "Draw", f"{away_team} Win"][outcome_idx]

                st.success(f"🏆 Predicted Outcome: **{outcome_label}**")
                c1, c2, c3 = st.columns(3)
                c1.metric(f"{home_team} Win", f"{home_pct:.1f}%")
                c2.metric("Draw", f"{draw_pct:.1f}%")
                c3.metric(f"{away_team} Win", f"{away_pct:.1f}%")
