# ⚽ Football Match Outcome Predictor

A machine learning web application that predicts football match outcomes (Home Win, Draw, or Away Win) using historical team statistics.

## 🚀 Features

- Predict football match outcomes
- Interactive Streamlit interface
- Team selection
- Tournament selection
- Neutral venue option
- Instant predictions

---

## 🤖 Machine Learning Models

Multiple machine learning models were trained and evaluated for this project:

- Logistic Regression ✅
- Decision Tree
- Random Forest
- Support Vector Machine (SVM)
- XGBoost

After comparing all models using classification performance metrics, **Logistic Regression** achieved the best overall performance and was selected as the final model for deployment.

---

## 🛠 Technologies Used

- Python
- Streamlit
- Scikit-learn
- Pandas
- NumPy
- Pickle

---

## 📂 Project Structure

Football-predictor/

├── streamlit_app.py

├── logisticModel.pkl

├── scaler.pkl

├── teamStats.pkl

├── requirements.txt

└── README.md

---

## ▶️ Run Locally

Install the required packages:

```bash
pip install -r requirements.txt
```

Start the application:

```bash
streamlit run streamlit_app.py
```

---

## 📌 Future Improvements

- Prediction probabilities
- Team comparison dashboard
- Recent match statistics
- Interactive visualizations
- Deep Learning models

---

## 👨‍💻 Author

**Muhammad Hamiz Bilal**

GitHub: https://github.com/Muhammadhamiz786