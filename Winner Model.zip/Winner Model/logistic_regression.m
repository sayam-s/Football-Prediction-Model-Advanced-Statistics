%% ============================================================
%  LOGISTIC REGRESSION ONLY — Football Match Outcome Prediction
%  + Top 10 Teams Ranking, shown as WIN PERCENTAGES
%    (vs. a league-average opponent, using each team's latest stats)
%
%  Note: fitcecoc's raw "score" output is a NegLoss value, not a
%  calibrated probability. To show it as a percentage, the 3 class
%  scores (Away/Draw/Home) are passed through softmax so they sum
%  to 100% per team. Treat this as a relative confidence measure,
%  not a strict statistical probability.
% =============================================================

data = readtable('football_encoded.csv');
head(data);

%% ============================================================
%  STEP 1 : Train-Test Split (80% Train, 20% Test)
% =============================================================

cv = cvpartition(height(data),'HoldOut',0.20);

trainData = data(training(cv),:);
testData  = data(test(cv),:);

%% ============================================================
%  STEP 2 : Define Target Variable
% =============================================================

target = "match_outcome";

%% ============================================================
%  STEP 3 : Define Numerical Features (Only These Will Be Scaled)
% =============================================================

numericVars = {
'home_elo'
'away_elo'
'elo_diff'

'home_avg_overall'
'home_maoverall'
'home_avg_attack'
'home_avg_defense'
'home_avg_pace'
'home_avg_shooting'
'home_avg_passing'

'away_avg_overall'
'away_maoverall'
'away_avg_attack'
'away_avg_defense'
'away_avg_pace'
'away_avg_shooting'
'away_avg_passing'

'overall_diff'
'attack_diff'
'defense_diff'

'home_form_scored'
'home_form_conceded'
'home_form_win_rate'

'away_form_scored'
'away_form_conceded'
'away_form_win_rate'
};

%% ============================================================
%  STEP 4 : Calculate Mean and Standard Deviation
%           (ONLY FROM TRAINING DATA)
% =============================================================

mu = mean(trainData{:,numericVars});
sigma = std(trainData{:,numericVars});

% Avoid division by zero
sigma(sigma==0) = 1;

%% ============================================================
%  STEP 5 : Scale Training Data
% =============================================================

trainData{:,numericVars} = ...
    (trainData{:,numericVars} - mu) ./ sigma;

%% ============================================================
%  STEP 6 : Scale Test Data
%           (Use SAME mu and sigma from Training Data)
% =============================================================

testData{:,numericVars} = ...
    (testData{:,numericVars} - mu) ./ sigma;

%% ============================================================
%  STEP 7 : Separate Features (X) and Target (Y)
% =============================================================

XTrain = removevars(trainData,target);
YTrain = trainData.(target);

XTest = removevars(testData,target);
YTest = testData.(target);

%% ============================================================
%  STEP 8 : Save Scaling Parameters
%           (Needed During Deployment)
% =============================================================

save('scaler.mat','mu','sigma','numericVars');

disp('Training and Testing data prepared successfully!');
head(trainData);

%% ============================================================
% STEP 9 : Logistic Regression with Cost Matrix
% ============================================================
costMatrix = [0 1 1;
              2 0 2;
              1 1 0];

t = templateLinear('Learner','logistic');
logisticModel = fitcecoc(XTrain, YTrain, 'Learners', t, 'Cost', costMatrix);

%% ============================================================
% STEP 10 : Predict on Test Data
% ============================================================
YPred = predict(logisticModel, XTest);

%% ============================================================
% STEP 11 : Test Accuracy
% ============================================================
accuracy = mean(YPred == YTest);
fprintf('Logistic Regression Accuracy = %.2f%%\n', accuracy*100);

%% ============================================================
% STEP 11B : Training Accuracy (to check overfitting)
% ============================================================
YPredTrain = predict(logisticModel, XTrain);
accuracyTrain = mean(YPredTrain == YTrain);
fprintf('Logistic Regression TRAINING Accuracy = %.2f%%\n', accuracyTrain*100);

%% ============================================================
% STEP 12 : Confusion Matrix
% ============================================================
confMat = confusionmat(YTest, YPred);
disp('Logistic Regression Confusion Matrix');
disp(confMat);

%% ============================================================
% STEP 13 : Confusion Chart
% ============================================================
figure;
confusionchart(YTest, YPred);
title('Logistic Regression Confusion Matrix (with Cost Matrix)');

%% ============================================================
% STEP 13B : Per-Class Recall
% ============================================================
classes = unique(YTest);
for i = 1:length(classes)
    c = classes(i);
    recall = sum(YPred == c & YTest == c) / sum(YTest == c);
    fprintf('Recall for class %s = %.2f%%\n', string(c), recall*100);
end

tabulate(data.match_outcome)
tabulate(YTrain)

save('logisticModel.mat', 'logisticModel');

%% ============================================================
% STEP 14 : Build "Latest Team Stats" Lookup Table
%           (needed so we have a per-team feature row to rank)
% ============================================================
rawData = readtable('football_prediction.csv');

if ~isdatetime(rawData.date)
    rawData.date = datetime(rawData.date, 'InputFormat', 'yyyy-MM-dd');
end

allTeams = unique([rawData.home_team; rawData.away_team]);
teamStats = table();

for i = 1:length(allTeams)
    team = allTeams(i);

    homeMatches = rawData(strcmp(rawData.home_team, team), :);
    awayMatches = rawData(strcmp(rawData.away_team, team), :);

    latestHomeDate = NaT;
    latestAwayDate = NaT;
    if ~isempty(homeMatches)
        latestHomeDate = max(homeMatches.date);
    end
    if ~isempty(awayMatches)
        latestAwayDate = max(awayMatches.date);
    end

    if isnat(latestHomeDate) && isnat(latestAwayDate)
        continue;
    end

    if isnat(latestAwayDate) || (~isnat(latestHomeDate) && latestHomeDate >= latestAwayDate)
        row = homeMatches(homeMatches.date == latestHomeDate, :);
        row = row(1,:);
        stats = table( ...
            row.home_elo, row.home_avg_overall, row.home_maoverall, ...
            row.home_avg_attack, row.home_avg_defense, row.home_avg_pace, ...
            row.home_avg_shooting, row.home_avg_passing, ...
            row.home_form_scored, row.home_form_conceded, row.home_form_win_rate, ...
            row.date, ...
            'VariableNames', {'elo','avg_overall','maoverall','avg_attack', ...
            'avg_defense','avg_pace','avg_shooting','avg_passing', ...
            'form_scored','form_conceded','form_win_rate','last_match_date'});
    else
        row = awayMatches(awayMatches.date == latestAwayDate, :);
        row = row(1,:);
        stats = table( ...
            row.away_elo, row.away_avg_overall, row.away_maoverall, ...
            row.away_avg_attack, row.away_avg_defense, row.away_avg_pace, ...
            row.away_avg_shooting, row.away_avg_passing, ...
            row.away_form_scored, row.away_form_conceded, row.away_form_win_rate, ...
            row.date, ...
            'VariableNames', {'elo','avg_overall','maoverall','avg_attack', ...
            'avg_defense','avg_pace','avg_shooting','avg_passing', ...
            'form_scored','form_conceded','form_win_rate','last_match_date'});
    end

    stats.team = team;
    teamStats = [teamStats; stats];
end

teamStats = movevars(teamStats, 'team', 'Before', 1);
save('teamStats.mat', 'teamStats');
disp('Team stats lookup table built successfully!');
head(teamStats)

%% ============================================================
% STEP 15 : Rank Top 10 Teams by WIN PERCENTAGE
%           Assumption: pit each team (as Home) against a
%           "league-average" Away opponent, using the same
%           feature columns/scaling the logistic model was
%           trained on, then convert the 3-class score into a
%           softmax percentage per team.
% ============================================================

% League-average AWAY-side stats, taken from the ORIGINAL (unscaled) data
avgAway = struct( ...
    'elo',          mean(data.away_elo), ...
    'avg_overall',  mean(data.away_avg_overall), ...
    'maoverall',    mean(data.away_maoverall), ...
    'avg_attack',   mean(data.away_avg_attack), ...
    'avg_defense',  mean(data.away_avg_defense), ...
    'avg_pace',     mean(data.away_avg_pace), ...
    'avg_shooting', mean(data.away_avg_shooting), ...
    'avg_passing',  mean(data.away_avg_passing), ...
    'form_scored',  mean(data.away_form_scored), ...
    'form_conceded',mean(data.away_form_conceded), ...
    'form_win_rate',mean(data.away_form_win_rate));

nTeams = height(teamStats);
homeWinPct = zeros(nTeams,1);
drawPct    = zeros(nTeams,1);
awayWinPct = zeros(nTeams,1);

% Template row: all predictor columns the model expects, in order
predictorNames = XTrain.Properties.VariableNames;
templateRow = XTrain(1,:); % just for structure/types

% Class order in logisticModel.ClassNames — used to locate each
% outcome's column in the score matrix (assumed labels: 0=Away,1=Draw,2=Home)
homeClassIdx = find(logisticModel.ClassNames == 2);
drawClassIdx = find(logisticModel.ClassNames == 1);
awayClassIdx = find(logisticModel.ClassNames == 0);

for i = 1:nTeams
    row = table();
    row.home_elo           = teamStats.elo(i);
    row.away_elo           = avgAway.elo;
    row.elo_diff           = teamStats.elo(i) - avgAway.elo;

    row.home_avg_overall   = teamStats.avg_overall(i);
    row.home_maoverall     = teamStats.maoverall(i);
    row.home_avg_attack    = teamStats.avg_attack(i);
    row.home_avg_defense   = teamStats.avg_defense(i);
    row.home_avg_pace      = teamStats.avg_pace(i);
    row.home_avg_shooting  = teamStats.avg_shooting(i);
    row.home_avg_passing   = teamStats.avg_passing(i);

    row.away_avg_overall   = avgAway.avg_overall;
    row.away_maoverall     = avgAway.maoverall;
    row.away_avg_attack    = avgAway.avg_attack;
    row.away_avg_defense   = avgAway.avg_defense;
    row.away_avg_pace      = avgAway.avg_pace;
    row.away_avg_shooting  = avgAway.avg_shooting;
    row.away_avg_passing   = avgAway.avg_passing;

    row.overall_diff = row.home_avg_overall - row.away_avg_overall;
    row.attack_diff  = row.home_avg_attack  - row.away_avg_attack;
    row.defense_diff = row.home_avg_defense - row.away_avg_defense;

    row.home_form_scored   = teamStats.form_scored(i);
    row.home_form_conceded = teamStats.form_conceded(i);
    row.home_form_win_rate = teamStats.form_win_rate(i);

    row.away_form_scored   = avgAway.form_scored;
    row.away_form_conceded = avgAway.form_conceded;
    row.away_form_win_rate = avgAway.form_win_rate;

    % Reorder to match predictor order, add any non-numeric columns
    % from XTrain as-is (categoricals etc.), if present
    missingCols = setdiff(predictorNames, row.Properties.VariableNames);
    for m = 1:numel(missingCols)
        row.(missingCols{m}) = templateRow.(missingCols{m});
    end
    row = row(:, predictorNames);

    % Scale using the SAME mu/sigma from training
    row{:,numericVars} = (row{:,numericVars} - mu) ./ sigma;

    [~, score] = predict(logisticModel, row);

    % Convert the 3 class scores into a percentage distribution
    probs = exp(score) / sum(exp(score));

    homeWinPct(i) = probs(homeClassIdx) * 100;
    drawPct(i)    = probs(drawClassIdx) * 100;
    awayWinPct(i) = probs(awayClassIdx) * 100;
end

teamStats.homeWinPct = homeWinPct;
teamStats.drawPct    = drawPct;
teamStats.awayWinPct = awayWinPct;

rankedTeams = sortrows(teamStats, 'homeWinPct', 'descend');

fprintf('\n=== TOP 10 TEAMS (Winning %% — normalized to sum to 100%%) ===\n');
top10 = rankedTeams(1:min(10,height(rankedTeams)), {'team','homeWinPct'});
top10.homeWinPct = top10.homeWinPct / sum(top10.homeWinPct) * 100;
top10.Properties.VariableNames{'homeWinPct'} = 'winningPct';
disp(top10);

%% ============================================================
% STEP 17 : FINAL — Argentina vs Spain (Head-to-Head)
%           Uses each team's actual latest stats from teamStats
%           (not the league-average opponent used for the
%           top-10 ranking above).
% ============================================================

homeTeamName = "Argentina";
awayTeamName = "Spain";

homeIdx = find(strcmp(teamStats.team, homeTeamName));
awayIdx = find(strcmp(teamStats.team, awayTeamName));

if isempty(homeIdx) || isempty(awayIdx)
    warning('Argentina and/or Spain not found in teamStats.team — check spelling/encoding.');
else
    finalRow = table();
    finalRow.home_elo           = teamStats.elo(homeIdx);
    finalRow.away_elo           = teamStats.elo(awayIdx);
    finalRow.elo_diff           = finalRow.home_elo - finalRow.away_elo;

    finalRow.home_avg_overall   = teamStats.avg_overall(homeIdx);
    finalRow.home_maoverall     = teamStats.maoverall(homeIdx);
    finalRow.home_avg_attack    = teamStats.avg_attack(homeIdx);
    finalRow.home_avg_defense   = teamStats.avg_defense(homeIdx);
    finalRow.home_avg_pace      = teamStats.avg_pace(homeIdx);
    finalRow.home_avg_shooting  = teamStats.avg_shooting(homeIdx);
    finalRow.home_avg_passing   = teamStats.avg_passing(homeIdx);

    finalRow.away_avg_overall   = teamStats.avg_overall(awayIdx);
    finalRow.away_maoverall     = teamStats.maoverall(awayIdx);
    finalRow.away_avg_attack    = teamStats.avg_attack(awayIdx);
    finalRow.away_avg_defense   = teamStats.avg_defense(awayIdx);
    finalRow.away_avg_pace      = teamStats.avg_pace(awayIdx);
    finalRow.away_avg_shooting  = teamStats.avg_shooting(awayIdx);
    finalRow.away_avg_passing   = teamStats.avg_passing(awayIdx);

    finalRow.overall_diff = finalRow.home_avg_overall - finalRow.away_avg_overall;
    finalRow.attack_diff  = finalRow.home_avg_attack  - finalRow.away_avg_attack;
    finalRow.defense_diff = finalRow.home_avg_defense - finalRow.away_avg_defense;

    finalRow.home_form_scored   = teamStats.form_scored(homeIdx);
    finalRow.home_form_conceded = teamStats.form_conceded(homeIdx);
    finalRow.home_form_win_rate = teamStats.form_win_rate(homeIdx);

    finalRow.away_form_scored   = teamStats.form_scored(awayIdx);
    finalRow.away_form_conceded = teamStats.form_conceded(awayIdx);
    finalRow.away_form_win_rate = teamStats.form_win_rate(awayIdx);

    missingCols = setdiff(predictorNames, finalRow.Properties.VariableNames);
    for m = 1:numel(missingCols)
        finalRow.(missingCols{m}) = templateRow.(missingCols{m});
    end
    finalRow = finalRow(:, predictorNames);

    finalRow{:,numericVars} = (finalRow{:,numericVars} - mu) ./ sigma;

    [finalLabel, finalScore] = predict(logisticModel, finalRow);
    finalProbs = exp(finalScore) / sum(exp(finalScore));

    rawHomeWinPct = finalProbs(homeClassIdx) * 100;
    rawDrawPct    = finalProbs(drawClassIdx) * 100;
    rawAwayWinPct = finalProbs(awayClassIdx) * 100;

    % A FINAL has no draw (extra time / penalties decide it), so
    % redistribute the Draw probability between Home and Away only
    finalHomeWinPct = rawHomeWinPct / (rawHomeWinPct + rawAwayWinPct) * 100;
    finalAwayWinPct = rawAwayWinPct / (rawHomeWinPct + rawAwayWinPct) * 100;

    fprintf('\n=== FINAL: %s vs %s (no draw possible) ===\n', homeTeamName, awayTeamName);
    fprintf('(raw model output — %s %.2f%%, Draw %.2f%%, %s %.2f%%)\n', ...
        homeTeamName, rawHomeWinPct, rawDrawPct, awayTeamName, rawAwayWinPct);
    fprintf('%s Win  = %.2f%%\n', homeTeamName, finalHomeWinPct);
    fprintf('%s Win  = %.2f%%\n', awayTeamName, finalAwayWinPct);

    if finalHomeWinPct > finalAwayWinPct
        fprintf('Predicted Winner: %s\n', homeTeamName);
    else
        fprintf('Predicted Winner: %s\n', awayTeamName);
    end
end